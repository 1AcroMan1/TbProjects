#ifndef LOAD
#define LOAD
void Load1(List* l, std::string fileName);
void Load2(List* l, std::string fileName);
#endif 
