#ifndef MOVE
#define MOVE
#include "List.h"
Node* Move(List* l, int index);
Node* MoveToRace(List* l, int race);
#endif MOVE