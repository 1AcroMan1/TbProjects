#ifndef SAVE
#define SAVE
void Save1(List* l, std::string fileName);
void Save2(List* l, std::string fileName);
#endif 