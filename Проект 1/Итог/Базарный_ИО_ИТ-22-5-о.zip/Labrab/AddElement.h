#ifndef ADD
#define ADD
#include "List.h"
void AddIntoBegin(List* l);
void AddIntoEnd(List* l);
void AddIntoBegin2(List* l, Node* ar2);
#endif