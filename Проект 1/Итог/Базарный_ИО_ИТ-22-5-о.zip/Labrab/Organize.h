#ifndef ORGANIZE
#define ORGANIZE
#include "List.h"
void Organize(List* l1);
#endif
