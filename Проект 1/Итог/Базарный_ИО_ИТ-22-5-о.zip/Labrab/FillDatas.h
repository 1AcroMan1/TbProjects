#ifndef FILL
#define FILL
#include "List.h"
void FillData(Node* ar);
void PrintPathName(Node* ar, bool nameFlag);
void PrintPlaneMark(Node* ar);
void PrintTotalRaceCost(Node* ar);
void PrintAmmountPassageers(Node* ar);
#endif