#ifndef DELETE
#define DELETE
#include "List.h"
void Remove(List* l, int index,bool needAsk);
void Clear(List* l);
#endif