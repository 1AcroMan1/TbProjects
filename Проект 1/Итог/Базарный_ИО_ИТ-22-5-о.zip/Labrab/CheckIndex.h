#ifndef CHECK_INDEX
#define CHECK_INDEX
bool CheckIndex(int index, int count);
#endif