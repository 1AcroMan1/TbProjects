#ifndef FOUND
#define FOUND
#include "List.h"
void Found(List* l2, std::string name);
#endif