#ifndef CORRECT
#define CORRECT
#include "List.h"
void Correct(List* l, int index);
#endif