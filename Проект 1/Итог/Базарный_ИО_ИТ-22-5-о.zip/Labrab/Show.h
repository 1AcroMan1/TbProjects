#ifndef SHOW
#define SHOW
#include "List.h"
void Show(List* l);
void FinalShow(List* l);
#endif
