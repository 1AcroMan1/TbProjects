#include "list.h"
#include <locale>
int main()
{
	ClientCode();
	return 0;
}