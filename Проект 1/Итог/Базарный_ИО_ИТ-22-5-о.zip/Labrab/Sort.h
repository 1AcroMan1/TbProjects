#ifndef SORT
#define SORT
void Sort(List* l, int keyType, bool isReverse);
#endif 